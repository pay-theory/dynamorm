// Package encoding provides utilities for encoding values for specific
// document encodings.

package encoding
